# JDSZR11-DatA_Team
## Project ML - Jak kosztowne jest zdrowie?

Conspect:
- Cel ML: określane kosztów zdrowia na podstawie parametrów ubezpieczonego
- Cel aplikacji: pomoc przy wyznaczaniu progu ubezpieczenia zdrowotnego
- <a href="https://www.kaggle.com/datasets/mirichoi0218/insurance">Kaggle dataset</a>



W projekcie podjęłam próbę stworzenia modeli :
#regresji liniowej
#Las losowy (random forest rf)
#strojenie parametrów
#decision_tree 
oraz opis wnioskow.